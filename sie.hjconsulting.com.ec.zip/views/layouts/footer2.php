<footer>
        <p>&copy; 2024 Sistema de Simulación de Contratación Pública</p>
    </footer>
    <script src="<?php echo js('moderator-dashboard.js'); ?>"></script>
</body>
</html>