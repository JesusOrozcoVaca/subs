<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Simulación de Contratación Pública</title>
    <link rel="stylesheet" href="<?php echo css('styles.css'); ?>">
</head>
<body>
    <header>
        <h1>Sistema de Simulación de Contratación Pública</h1>
        <p>Bienvenido, <?php echo $_SESSION['nombre_completo']; ?></p>
    </header>