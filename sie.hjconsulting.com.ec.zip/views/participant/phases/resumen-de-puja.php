<h2>Resumen de Puja</h2>
<div id="resumen-puja-container">
    <div id="ganador-puja">
        <!-- Aquí se mostrará el ganador de la puja -->
    </div>
    <div id="tabla-resultados">
        <!-- Aquí se mostrará una tabla con los resultados de la puja -->
    </div>
    <div id="grafico-pujas">
        <!-- Aquí se podría incluir un gráfico de las pujas realizadas -->
    </div>
</div>