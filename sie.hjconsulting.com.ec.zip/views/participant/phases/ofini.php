<h2>Oferta Inicial</h2>
<div id="oferta-inicial-container">
    <form id="oferta-inicial-form">
        <input type="number" name="valor_oferta" placeholder="Ingrese el valor de su oferta inicial" step="0.01">
        <button type="submit">Enviar Oferta Inicial</button>
    </form>
    <div id="oferta-actual">
        <!-- Aquí se mostrará la oferta inicial actual -->
    </div>
</div>