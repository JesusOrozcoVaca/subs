<h2>Entrega de Ofertas</h2>
<div id="entrega-ofertas-container">
    <form id="oferta-form" enctype="multipart/form-data">
        <input type="file" name="documento_oferta" accept=".pdf,.doc,.docx">
        <button type="submit">Subir Oferta</button>
    </form>
    <div id="lista-ofertas">
        <!-- Aquí se mostrarán las ofertas subidas -->
    </div>
</div>