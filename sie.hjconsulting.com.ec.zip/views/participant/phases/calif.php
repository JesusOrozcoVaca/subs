<h2>Calificación</h2>
<div id="entrega-ofertas-container">
    Aqui el usuario verá la calificación que se le ha asignado para el presente proceso.
    <div id="lista-ofertas">
        <!-- Aquí se mostrarán las ofertas subidas -->
    </div>
</div>