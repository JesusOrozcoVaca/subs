<h2>Preguntas y Respuestas</h2>
<div id="preguntas-respuestas-container">
    <form id="pregunta-form">
        <textarea name="pregunta" placeholder="Escriba su pregunta aquí"></textarea>
        <button type="submit">Enviar Pregunta</button>
    </form>
    <div id="lista-preguntas">
        <!-- Aquí se cargarán dinámicamente las preguntas y respuestas -->
    </div>
</div>