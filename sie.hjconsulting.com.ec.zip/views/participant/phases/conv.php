<h2>Convalidación de Errores</h2>
<div id="convalidacion-errores-container">
    <div id="errores-a-convalidar">
        <!-- Aquí se mostrarán los errores que requieren convalidación -->
    </div>
    <form id="convalidacion-form">
        <textarea name="respuesta_convalidacion" placeholder="Escriba su respuesta de convalidación aquí"></textarea>
        <input type="file" name="documento_convalidacion" accept=".pdf,.doc,.docx">
        <button type="submit">Enviar Convalidación</button>
    </form>
</div>